# Nissi Engineering Department

**NED** es el nombre corto de **Nissi Engineering Department**. En instrucciones y conversaciones, las referencias a «NED» o «el departamento NED» designan este mismo departamento y su gobernanza. El alias no cambia nombres de repositorios, paquetes ni comandos.

Nissi Engineering Department is a local-first, provider-independent foundation for planning engineering work with explicit risk, cost, quality, review, and institutional-memory controls. Version `0.3.0` combines the `0.2.0` planning and Nissi UX Architect foundation with task-local context, structured evidence, delivery learning and operator-pinned acceptance coverage. It does not pretend to execute external AI or certify legal, privacy, tax, security, browser or release outcomes.

## Why it exists

Engineering assistants often hide policy in prompts, lose project knowledge in conversations, and activate more reasoning than a task needs. Nissi keeps durable knowledge in the consumer repository, evaluates deterministic signals before involving providers, and separates the component that decides a plan from the adapter that may later execute it.

## Architecture

The strict TypeScript ESM monorepo has focused packages:

- `core`: provider-neutral contracts, registries, validation, loading, and plan serialization.
- `risk-engine`: explicit keyword, metadata, and profile risk floors across seven dimensions.
- `cost-governor`: configurable bootstrap policy, abstract reasoning classes, and capability-driven specialist selection.
- `orchestrator`: risk → cost → agent selection → workflow → gates → review planning.
- `ticket-engine`: deterministic normalization, classification, severity, routing, and escalation.
- `quality-engine`: real local checks for secret patterns, dangerous configuration, risky sinks, dependencies, and Git diffs.
- `provider-codex`: translates a completed plan into Codex-compatible instructions without API calls or credentials.
- `cli`: safe consumer-project initialization, diagnosis, planning, audit, review, and managed-resource sync.

Agents, departments, skills, policies, profiles, workflows, gates, and schemas live outside the orchestrator. Agent and skill manifests are versioned JSON so v0.1 can parse and validate them with no runtime dependency. Consumer configuration and registers use YAML.

## Installation

The package metadata is prepared for a future npm publication, but v0.1 has not been published by this repository task. From a packed or published package:

```bash
npm install -D @nissi/engineering-department
npx nissi-engineering init
npx nissi-engineering doctor
```

For repository development:

```bash
npm install
npm run build
node dist/packages/cli/src/index.js --help
```

## CLI

```text
nissi-engineering init
nissi-engineering doctor
nissi-engineering plan "Describe the task"
nissi-engineering audit
nissi-engineering review
nissi-engineering sync
```

All commands accept `--root <path>`. `init` only creates missing project-owned files and is idempotent. `sync` only replaces JSON carrying `"managedBy": "nissi"`; an unmarked or invalid existing file is preserved. `audit` performs local static checks and never sends code elsewhere. `review` inspects deterministic audit results and the Git diff, then requests independent human review when a tracked diff exists—it does not fabricate an AI review.

## NED-CALIDAD — 0.3.0

The `0.3.0` release adds task-local context, conclusive evidence contracts, delivery learning and operator-pinned acceptance coverage. Existing installed `0.2.0` packages are not silently replaced. Package installation remains explicit and product acceptance remains separate from library release.

```text
nissi-engineering context "Adjust the purchase form" --root PROJECT --files src/Form.tsx --required AGENTS.md --max-bytes 65536
nissi-engineering evidence .nissi/reports/test-evidence.json --root PROJECT
nissi-engineering learning .nissi/reports/delivery-learning.json --root PROJECT
nissi-engineering acceptance contract.json delivery.json --contract-sha256 OPERATOR_SHA256 --root PROJECT
```

`context` reads known project-local instructions before optional dependencies and returns only a path/hash/byte manifest. Mandatory instructions may exceed the optional budget; known missing/unsafe requirements yield INSUFFICIENT and a nonzero exit code. It does not scan the entire repository, print source contents or replace inherited/session/skill instructions. Metrics cover collector I/O only, never total assistant reading, tokens or cost. See `policies/engineering/TASK-CONTEXT.md`.

`evidence` verifies a structured report's identified subjects, explicit preconditions, expected/observed assertions and actual local artifact hashes. A required unexecuted criterion, absent control, mismatched assertion, invalid contract or unsafe/missing/tampered artifact cannot pass. Paths are relative to the explicit root, not the report's directory. Reads are limited to 1 MiB for a report and 32 MiB/artifact, 64 MiB/report for unique artifacts; links/traversal and known sensitive paths are rejected. Choose a separate private evidence root if artifacts live outside a project. No report command is executed. Success verifies report consistency and local hashes, **not independent observation, browser execution, user understanding or release approval**. The planned gate has no result until a concrete report is checked.

`learning` summarizes one record or an array without double counting record ids or mixing currencies; unknown measurements remain null and savings are never inferred. Record escaped defects and corrections, review controls with evidence, and preserve independent/human review before removing safeguards.

`acceptance` compares a delivery against a separate operator-pinned contract: exact candidate subject/revision, required criteria and variants, expected checks, host/mobile/session context, regression mappings from selected pinned learning records and executed passing stages with a distinct declared reviewer. Omissions block even when the reduced evidence report alone passes integrity. See [the acceptance policy](policies/engineering/ACCEPTANCE.md), `templates/ACCEPTANCE-CONTRACT.json` and `templates/ACCEPTANCE-DELIVERY.json`. The operator must establish and protect the pin before implementation and confirm real review. The verifier does not observe a browser, authenticate identities or approve a release.

Packaged resources include `templates/VISUAL-DIRECTION.md`, `templates/TEST-EVIDENCE.json`, `templates/DELIVERY-LEARNING.json`, their schemas and the context policy. The evidence template intentionally fails until executed. These reinforce existing UX/product/QA/reviewer roles, preserve business authorization, require proportional alternatives and a product-specific identity, and do not create a Research department or execute specialist agents.

## Project memory

Initialization creates `AGENTS.md` and the following consumer-owned structure outside `node_modules`:

```text
.nissi/
├── project.yaml
├── PRODUCT.md
├── ARCHITECTURE.md
├── ROADMAP.md
├── TECH-DEBT.md
├── DATA-REGISTRY.yaml
├── RISK-REGISTER.yaml
├── ADR/
├── RFC/
├── audits/
├── incidents/
├── tickets/
├── reports/
└── managed/
```

Documents and registers are project-owned. Files under `.nissi/managed/` are package-maintained only while their ownership marker remains intact.

## Profiles

Profiles are registry-loaded configuration, not large conditional branches:

- `generic`: conservative mixed-project baseline.
- `react-library`: UI compatibility and accessibility emphasis.
- `enterprise-saas`: tenant, security, privacy, support, legal, and finance awareness.
- `backend-framework`: API, data, delivery, and compatibility emphasis.

`init` detects npm/pnpm/yarn/bun, Node, TypeScript, React, Vite, Next.js, common test and database tooling, Docker, Git, and common CI files to suggest a profile.

## Agents, skills, policies, and gates

Agent manifests declare capabilities, activation, abstract cost preference, authority, skills, escalation, and outputs. Skills are versioned procedures rather than personas. Policies remain reviewable files outside provider instructions. A gate returns `PASS`, `FAIL`, `WARNING`, `SKIPPED`, or `HUMAN_REVIEW` and may block release.

No agent is authorized to approve its own significant work. High-risk plans add an independent reviewer; critical security incidents, sensitive-data processing, material legal interpretation, tax-sensitive changes, and significant financial operations require human review.

## Risk and cost governance

Risk dimensions are `technical`, `security`, `privacy`, `legal`, `financial`, `business`, and `operational`, each from `none` through `critical`. Profile and request metadata can raise deterministic floors.

The `CostGovernor` uses provider-neutral `economy`, `standard`, `advanced`, and `critical` classes. Bootstrap mode defaults to four recommended specialists. Essential coverage may exceed that cap only with a recorded justification. Concrete model selection belongs to a provider, not the domain.

## Workstreams (v0.1.1 dogfood foundation)

Consumer-owned roadmap memory lives under `.nissi/workstreams/<id>/workstream.yaml`. The file is serialized as indented JSON, which is valid YAML 1.2 and keeps the foundation dependency-free. A workstream contains ordered phases; phases can contain tasks, and tasks can reference ticket ids.

```text
nissi-engineering workstreams --root <path>
nissi-engineering status --root <path>
nissi-engineering resume --root <path>
nissi-engineering next --root <path>
```

`next` only recommends an actionable phase whose declared dependencies are complete. It refuses to recommend work when dependencies are missing or cyclic. `resume` deliberately emits a compact subset of project state, evidence, files, capabilities, risk, and reasoning class.

## Codex integration

The current adapter only renders structured instructions, skill references, gates, reasoning class, and human-review requirements from an existing plan. It performs no OpenAI API call, invents no hidden Codex API, reads no token, and stores no credential.

## Security philosophy

The CLI is conservative: it does not delete consumer files, execute commands from configuration, load remote code, send source externally, or read unrelated secrets. Static checks are defensive signals, not security certification. Authentication, authorization, tenant isolation, dependency, injection, XSS, SSRF, CSRF, CORS, upload, privilege, and sensitive-logging concerns are represented by policies, risk rules, skills, or gates.

## Capability status

Available in v0.1:

- Manifest/profile loading and validation; deterministic risk, cost, planning, ticket routing, and initial quality checks.
- Safe project memory initialization, diagnosis, managed sync, JSON plan output, and Codex instruction rendering.
- Automated offline tests and CI for install, typecheck, lint, test, and build.

Experimental in v0.1:

- Heuristic framework/database detection, static security patterns, task classification, and profile suggestions.
- Declarative policy/gate catalogs that are not all executable yet.

Planned, not available:

- External provider execution, richer YAML parsing, exhaustive dependency vulnerability data, persistent orchestration, dashboards, cloud services, databases, billing, and marketplaces.

## Development

```bash
npm run typecheck
npm run lint
npm test
npm run build
```

Architecture decisions are in `docs/adr/`; major future work starts from `templates/RFC.md` and proceeds through architecture review, risk review, implementation, deterministic gates, and independent review.

## Roadmap

The plugin/registry expansion that was originally pencilled in for a "v0.2 milestone" is **not** part of the 0.2.0 package and remains a proposal without a version assigned: public extension APIs, a constrained full YAML parser, executable policy and gate registries, richer project detection, signed managed-resource metadata, and an opt-in provider execution boundary. It should not introduce a dashboard, central service, or background agents.

RFC drafts live in `docs/rfc/`. `docs/rfc/RFC-0001-agent-capacity-and-department-gaps.md` records real activation/risk-calibration gaps found by dogfooding `plan` against a live consumer project. Its scoped calibration fixes (items 1-6: concurrency signal, cosmetic-auth narrowing in both risk-engine and cost-governor, Spanish keyword coverage, deeper `engineering.ux`/`product.analyst` skills, an `executionModel` disclosure field) are implemented; the Research/User Insights department question was deliberately deferred (no real users yet); independent provider execution (item 7) remains a distinct, not-yet-started initiative.

## Nissi UX Architect

The existing engineering.ux role is named **Nissi UX Architect** (1.2.0 in this development candidate). Its [role protocol](agents/engineering.ux.md) and [per-screen review template](templates/UX-REVIEW.md) cover diagnosis, severity, layout, interaction/accessibility, NissiUI reuse, implementation planning, actual test evidence and a final verdict.

Interface tasks in English or Spanish recommend UX as essential, select user-interface-change when that workflow is available, and include accessibility. The workflow places UX design before implementation and evidence review after quality checks; non-interface tasks retain project-change. Significant product changes require approval within the existing authorization rules; routine authorized presentation changes do not acquire a blanket approval requirement.

Plans remain recommendation-only. The provider renders these requirements and resource references; it does not execute a UX agent, run browser tests or certify accessibility. Missing evidence cannot be replaced by a successful build. Existing installed packages require a separate update to receive new planner resources; the protocol can also be adopted in consumer-owned project instructions.

Note: paths such as `docs/adr/`, `docs/rfc/` and `.nissi/` named in this README and AGENTS.md exist in the source repository or in a consumer project, not inside the npm package. The package ships `agents/`, `templates/`, `workflows/`, `skills/` and the compiled `dist/`; the accessibility gate is a recommended check name, not an automated accessibility test.
