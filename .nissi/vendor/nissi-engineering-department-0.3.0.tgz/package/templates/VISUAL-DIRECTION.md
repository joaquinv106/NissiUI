# Dirección visual de [producto / pantalla]

Estado: propuesta; pendiente de revisión. Autor/ejecutor real, fecha, revisión de código y alcance autorizado:

## Persona, tarea y criterio humano

Quién lo usa, tarea, fricción, lenguaje, recuperación y beneficio verificable. Distinguir fuentes, observaciones reales e hipótesis; no inventar entrevistas, satisfacción ni resultados comerciales.

## Personalidad y referencias

Tres rasgos concretos, tono y densidad adecuados a la tarea; referencias justificadas y procedencia. Conservar decisiones aprobadas; no copiar una marca ni imponer la misma estética a todos los productos.

## Alternativas proporcionales

Para cambios significativos, dos alternativas concretas con jerarquía, distribución y tradeoffs; recomendar una por tarea/evidencia. Para un ajuste pequeño autorizado basta una propuesta breve. Reutilizar aprobación vigente; aprobar solo ampliaciones reales.

## Sistema visual y NissiUI

| Elemento | Contrato/token/activo inspeccionado | Propuesta y motivo | Responsable y compatibilidad |
| --- | --- | --- | --- |
| Color y contraste | Tokens semánticos, modos/estados | [Completar] | [Completar] |
| Tipografía | Escala, pesos y legibilidad | [Completar] | [Completar] |
| Espaciado/densidad | Tokens, alineación, tacto | [Completar] | [Completar] |
| Componentes | API pública NissiUI y variantes | Reutilización o hueco demostrado | [Completar] |
| Recursos gráficos | Íconos/ilustraciones/imágenes, origen/licencia | Archivos existentes o pendientes | [Completar] |

Para un token/componente compartido identificar propietario de biblioteca/arquitectura, consumidores, documentación y compatibilidad antes de cambiarlo. No editar dist ni NissiUI incidentalmente. No declarar recursos producidos sin archivos.

## Estados y movimiento

Carga, vacío, error, éxito, deshabilitado, foco, selección y confirmación; recuperación sin perder borradores. Movimiento con propósito y alternativa `prefers-reduced-motion`.

## Verificación y decisión

Matriz de rutas × viewport/orientación × tema × sesión/rol × vacío/poblado pertinente; teclado/foco/tacto y controles sin force. Precondiciones y resultados esperados; UX-REVIEW.md y TEST-EVIDENCE.json. Separar capturas, operabilidad, accesibilidad y estudios con personas. Identificar dispositivos o revisiones no ejecutados.

Resultado: recomendado / requiere cambios / evidencia insuficiente. Aprobación real identificada cuando corresponda, sin autoprobación de trabajo significativo.
