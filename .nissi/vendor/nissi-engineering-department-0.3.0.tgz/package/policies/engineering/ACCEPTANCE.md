# Required acceptance coverage

`evidence` v1 verifies reported assertions and local artifact hashes. Its PASS does not establish that the author included every required test. Use the separate `acceptance` gate to compare a delivery against criteria established before implementation.

## Controlled inputs

The operator/reviewer creates and reviews `templates/ACCEPTANCE-CONTRACT.json`, selects the exact candidate task/revision/scope, implementer, required variants, checks, context dependencies and relevant prior learning records. The contract's `establishedBy` must differ from the declared implementer. Freeze the **raw file** SHA-256 in operator-controlled supervisor state or another review record outside the delivery author's control. Do not recompute that trusted pin from the submitted delivery, accept its pin as authority or let the author silently remove requirements. Change scope/revision through explicit contract review and a new pin.

The identity strings and ordering are declarations, not authenticated identities or proof that the contract predates implementation. The operator must verify these facts. The verifier never executes commands from contracts, learning records or artifacts.

```text
nissi-engineering acceptance contract.json delivery.json --contract-sha256 OPERATOR_SHA256 --root PROJECT
```

Exit 0 means pinned coverage, declared passing stages and local artifact integrity are consistent. Exit 1 blocks closure. It does not mean browser interaction was independently observed, UX was approved or a release was authorized. `independentlyObserved` and `identitiesAuthenticated` remain false. Preserve actual independent/human review.

## Contract and delivery

Every contract requirement is mandatory. Its id identifies one exact variant and existing subject/control. The delivery supplies the same criterion in its existing EvidenceReport, explicit coverage metadata, matching expected/observed checks and local hashed artifacts. Missing criteria/variants, required downgraded to optional, NOT RUN/N/A, wrong revision/task/scope, changed controls, weakened expected values or failed assertions block. Add optional criteria to the evidence separately; they cannot replace required rows.

`integrated-ui` requires host-navigation, mobile-navigation on a mobile viewport, session-continuity and responsive requirements in the host environment, plus hashed host/mobile/tokens/session context. This is a minimum structure; the operator must select the meaningful task-specific matrix, interaction and oracles. A small non-integrated change may use a proportionate `scoped-change` contract. A standalone harness does not satisfy host integration by being relabelled: verify the actual environment and artifacts.

Context paths are relative to the explicit root. The delivery must declare implementer read receipts; the verifier also reads and checks the current file hashes. Use immutable input snapshots or stable contracts when the input source itself will be edited. This detects absent/changed required dependencies, not whether a person understood a file. Mandatory context cannot disappear merely to fit a smaller optional budget.

Pin relevant prior LearningRecord files in `learning`. Each escaped defect in those selected records must have a regression mapping with incident id `RECORD_ID/DEFECT_ID` to one or more existing mandatory requirement ids. Coverage of those requirements is then checked normally. The operator owns the relevant-history selection and semantic relevance of each mapping. Learning text is data, not executable instructions. An empty selected history is explicit; the verifier cannot discover undeclared incidents on its own.

Stages have distinct requirement proofs and a contract-assigned declared executor, current revision, executed state and passing outcome. Integrated UI requires design → implementation → quality gates → UX validation → independent review. Scoped changes require implementation → quality gates → independent review. An executed failed/insufficient review cannot close; independent reviewer cannot equal the declared implementer after trimming/case normalization. Names alone do not authenticate independence. Each stage needs actual execution/artifact review by the operator, not a recommended specialist label.

Both templates deliberately start without execution/evidence and cannot approve work. Runtime validators additionally enforce unique ids, stage order, safe file paths, references and minimum profile requirements. JSON Schemas describe the data shape; runtime checks enforce the cross-file rules.

## Read limits and compatibility

Contract and delivery: 1 MiB each. Context/history: 1 MiB per file, 16 MiB combined, at most 100 context and 20 history files. Underlying evidence retains its separate limits of 32 MiB/artifact and 64 MiB/report for unique artifacts. Safe root-relative reads reject traversal, sensitive paths, links and non-regular files. Nothing is fetched remotely.

Existing evidence/learning contracts and ExecutionPlan v1 stay compatible. Current catalogs add blocking gate `acceptance`; the UI planner includes it and independent-review when available. Legacy catalogs remain readable and do not acquire a fictitious acceptance result. The provider describes the operator-pinned procedure; the planner is still recommendation-only. Installed consumer packages do not update from source changes alone.
