# Repository instructions

Nissi Engineering Department is a provider-independent governance foundation.

- Inspect existing code, configuration, and repository state before modifying anything.
- Preserve package and domain boundaries; providers execute plans but never own core decisions.
- Prefer small interfaces, composition, registries, declarative manifests, and backwards-compatible changes.
- Keep TypeScript strict and avoid `any`.
- Add tests for behavior and never weaken tests merely to make them pass.
- Avoid unnecessary dependencies and infrastructure.
- Never expose secrets, store credentials, load remote code, or send project content externally.
- Apply least privilege and safe, auditable defaults.
- Significant work requires independent or human review; agents must not approve their own work.
- Record consequential architecture decisions in `docs/adr/` and prefer incremental changes.
- Respect bootstrap cost governance: activate only specialists justified by risk and complexity.

