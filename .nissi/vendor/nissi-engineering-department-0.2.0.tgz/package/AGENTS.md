# Repository instructions

**NED** es el nombre corto de **Nissi Engineering Department**. En instrucciones y conversaciones, las referencias a «NED» o «el departamento NED» designan este mismo departamento y su gobernanza. El alias no cambia nombres de repositorios, paquetes ni comandos.

Nissi Engineering Department is a provider-independent governance foundation.

- Inspect existing code, configuration, and repository state before modifying anything.
- Before proposing new agent/department work, check `docs/rfc/` for open drafts — e.g. `docs/rfc/RFC-0001-agent-capacity-and-department-gaps.md` records real, evidenced gaps found by dogfooding `plan` against a live consumer project (NissiPlatform/Shevaj Food), not yet implemented.
- Preserve package and domain boundaries; providers execute plans but never own core decisions.
- Prefer small interfaces, composition, registries, declarative manifests, and backwards-compatible changes.
- Keep TypeScript strict and avoid `any`.
- Add tests for behavior and never weaken tests merely to make them pass.
- Avoid unnecessary dependencies and infrastructure.
- Never expose secrets, store credentials, load remote code, or send project content externally.
- Apply least privilege and safe, auditable defaults.
- Significant work requires independent or human review; agents must not approve their own work.
- Record consequential architecture decisions in `docs/adr/` and prefer incremental changes.
- Respect bootstrap cost governance: activate only specialists justified by risk and complexity.


- For interface work, apply [Nissi UX Architect](agents/engineering.ux.md) during requirements, before implementation and after delivery; use [the per-screen review template](templates/UX-REVIEW.md). Preserve existing authorization, business contracts and independent-review requirements.
