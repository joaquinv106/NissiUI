# RFC-NNNN — Title

## Status
Draft

## Problem and business value

## Proposed solution

## Alternatives

## Security, privacy, legal, financial, and operational risk

## Compatibility and migration

## Test and rollout plan

## Reviews

- Architecture review:
- Risk review:
- Independent review:

## Decision

