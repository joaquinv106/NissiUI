# Cost policies

Bootstrap mode defaults to at most four recommended specialists, avoids unnecessary activation, and uses abstract economy/standard/advanced/critical reasoning classes. Advanced or critical reasoning requires recorded justification.

