# Engineering policies

- `engineering.strict-typescript`: TypeScript code uses strict mode and does not introduce unjustified `any`.
- `engineering.testing`: behavior changes require proportionate automated evidence.
- `engineering.backwards-compatibility`: public compatibility is preserved or explicitly versioned and migrated.
- `engineering.no-self-approval`: an author or executing agent cannot approve significant work it produced.

