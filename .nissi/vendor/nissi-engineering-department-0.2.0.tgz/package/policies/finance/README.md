# Finance policies

Payment and billing changes require review. Tax-sensitive behavior and irreversible financial actions require qualified human validation. Automated results are not accounting or tax advice.

