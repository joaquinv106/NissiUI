# Legal policies

Track dependency licenses and signal when terms or privacy documents may be required. Material contracts, policy changes, and interpretations require qualified human review. Output is not definitive legal advice.

