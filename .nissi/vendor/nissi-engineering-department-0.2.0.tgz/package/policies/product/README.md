# Product policies

Prioritize validated customer and business value. State the problem, target customer, MVP evidence, effort, monetization, and success measure before large investment.

