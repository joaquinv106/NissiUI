# Growth policies

Growth plans define an audience, ethical positioning, measurable acquisition and conversion outcomes, and do not fabricate customer evidence.

