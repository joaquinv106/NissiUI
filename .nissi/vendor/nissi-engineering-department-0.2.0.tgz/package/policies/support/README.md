# Support policies

Tickets are normalized, risk-assessed, severity-classified, routed, escalated when required, and tracked without unnecessarily exposing customer data.

