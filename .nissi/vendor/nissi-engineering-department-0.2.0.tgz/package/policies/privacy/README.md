# Privacy policies

Declare purpose, minimize data, define retention, restrict access, support deletion, and maintain the personal-data registry. Highly sensitive processing requires qualified human review. Automated results are risk signals, not professional legal advice.

