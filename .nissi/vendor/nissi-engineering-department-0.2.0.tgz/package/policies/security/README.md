# Security policies

- Never commit secrets or exposed credentials.
- Apply least privilege, dependency awareness, and secure defaults.
- Changes to authentication, authorization, tenant isolation, or privilege boundaries require security review.
- Review injection, XSS, SSRF, CSRF, CORS, uploads, and sensitive logging where relevant.
- Critical incidents block release and require human command.

